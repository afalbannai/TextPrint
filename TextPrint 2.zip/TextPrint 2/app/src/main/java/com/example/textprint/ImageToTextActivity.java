package com.example.textprint;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

/**

 The ImageToTextActivity class displays the recognized text from an image.

 It retrieves the text from the intent extras and sets it in a TextView.
 */
public class ImageToTextActivity extends AppCompatActivity {
    TextView textView;

    /**

     Called when the activity is starting. Initializes the UI components and sets the recognized text.

     @param savedInstanceState the saved instance state Bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_to_text);

// Initialize the TextView
        textView = findViewById(R.id.textView);

// Set the recognized text from the intent extras
        textView.setText(getIntent().getStringExtra("text"));
    }
}