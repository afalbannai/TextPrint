package com.example.textprint;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.io.IOException;

/**

 It allows the user to capture an image using the camera or select an image from the gallery,

 and then performs text recognition on the selected image.
 */
public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    TextView galleryBtn, camera;
    ProgressDialog progressDialog;

    /**

     Called when the activity is starting. Initializes the UI components and sets up click listeners.

     @param savedInstanceState the saved instance state Bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

// Initialize UI components
        imageView = findViewById(R.id.image);
        galleryBtn = findViewById(R.id.galley);
        camera = findViewById(R.id.camera);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Getting text.....");

// Set click listener for the camera button
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCameraForResult();
            }
        });

// Set click listener for the gallery button
        galleryBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                galleryResultLauncher.launch(intent);
            }
        });
    }

    /**

     Opens the camera to capture an image and process it for text recognition.
     */
    public void openCameraForResult() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraResultLauncher.launch(intent);
    }
    ActivityResultLauncher<Intent> cameraResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        assert result.getData() != null;
                        Bundle extras = result.getData().getExtras();
                        Bitmap bitmap = (Bitmap) extras.get("data");
                        detectText(bitmap);
                    } else {
                        Toast.makeText(MainActivity.this, "Not Captured", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    ActivityResultLauncher<Intent> galleryResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        assert result.getData() != null;
                        Uri uri = result.getData().getData();
                        try {
                            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                            detectText(bitmap);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });

    /**

     Performs text recognition on the given bitmap image.

     @param bitmap the bitmap image to perform text recognition on
     */
    private void detectText(Bitmap bitmap) {
        progressDialog.show();
        TextRecognizerOptions options = new TextRecognizerOptions.Builder().build();
        TextRecognizer textRecognizer = TextRecognition.getClient(options);

        InputImage image = InputImage.fromBitmap(bitmap, 0);
        textRecognizer.process(image)
                      .addOnSuccessListener(new OnSuccessListener<Text>()
                      {
                          @Override
                          public void onSuccess(Text text)
                          {
                              StringBuilder sb = new StringBuilder();
                              for (Text.TextBlock block : text.getTextBlocks())
                              {
                                  for (Text.Line line : block.getLines())
                                  {
                                      sb.append(line.getText());
                                      sb.append("\n");
                                  }
                                  sb.append("\n");
                              }
                              if (sb.toString()
                                    .equals(""))
                              {
                                  Toast.makeText(MainActivity.this, "No text found", Toast.LENGTH_SHORT)
                                       .show();
                              }
                              else
                              {
                                  Intent intent = new Intent(MainActivity.this, ImageToTextActivity.class);
                                  intent.putExtra("text", sb.toString());
                                  startActivity(intent);
                              }
                              progressDialog.dismiss();
                          }
                      });
    }
}